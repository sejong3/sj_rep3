x = 3
print x
if x < 5:
    x = x + 1
    print x
