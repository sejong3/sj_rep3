for i in range(5,26, 5):
    print i
print "End of First Loop!!!"

for i in range(10,1, -1):
    print i
print "End of Second Loop!!!"
