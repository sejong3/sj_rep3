Number_stars = int(raw_input("How many stars do you want?"))
for i in range(1,7):
  print "_*"*(2*i-1)
    

