for loop_counter in range(1,11):
    print loop_counter,": Hello"

print "End of For Loop!!!"
