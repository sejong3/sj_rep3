input1 = raw_input("Enter the first input value : ")
input2 = raw_input("Enter the second input value : ")

if input1 < input2:
   print input1, "is less than", input2
   print input1,"is not equal to", input2
elif input1> input2:
   print input1, "is greater than", input2
   print input1, "is not equal to", input2
else:
   print input1, "is equal to", input2
   
