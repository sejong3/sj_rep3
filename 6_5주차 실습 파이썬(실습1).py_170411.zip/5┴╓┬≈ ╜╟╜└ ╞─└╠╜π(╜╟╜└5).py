input1 = raw_input("Enter the first input value : ")
input2 = raw_input("Enter the second input value : ")

if (input1 < input2) and (int(input1) * 2) > int(input2):
   print input1, "is less than", input2, "."
   print "But multiple of", input1, "is greater than", input2

if input1 < input2 or input1 > input2:
   print input1, "is not equal to", input2
   
