input1 = raw_input("Enter the first input value : ")
input2 = raw_input("Enter the second input value : ")


if int(input1) < int(input2):
    print int(input1), "is less than", int(input2)
if int(input1) > int(input2):
    print int(input1), "is greater than", int(input2)
if int(input1) == int(input2):
    print int(input1), "is equal to", int(input2)
if int(input1) != int(input2):
    print int(input1), "is not equal to", int(input2)
